import turtle

# Set up the screen and turtle
screen = turtle.Screen()
t = turtle.Turtle()

# Set pen color and size
t.color("purple")  # Choose any color you like
t.pensize(5)       # Set the pen size

# Draw the initial "J"
t.penup()
t.goto(-100, 50)   # Start position for "J"
t.pendown()
t.right(90)        # Face the turtle downward
t.forward(100)     # Draw the long part of "J"
t.circle(-30, 180) # Draw the curved bottom of "J"

# Move to position for "P"
t.penup()
t.goto(50, 50)     # Move to the right for "P"
t.pendown()

# Draw the initial "P"
t.left(90)         # Face the turtle upward
t.forward(100)     # Draw the vertical line of "P"
t.right(90)        # Prepare to draw the loop
t.circle(-30, 180) # Draw the top half circle of "P"

# Finish drawing
turtle.done()
