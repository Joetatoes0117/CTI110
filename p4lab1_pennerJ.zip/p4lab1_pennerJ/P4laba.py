import turtle

# Set up the screen and turtle
screen = turtle.Screen()
t = turtle.Turtle()

# Draw a square
t.penup()
t.goto(-50, 0)  # Move turtle to a starting position
t.pendown()
for _ in range(4):
    t.forward(100)  # Move forward by 100 units
    t.right(90)     # Turn right by 90 degrees

# Draw a triangle
t.penup()
t.goto(100, 0)  # Move turtle to a new position for the triangle
t.pendown()
for _ in range(3):
    t.forward(100)  # Move forward by 100 units
    t.left(120)     # Turn left by 120 degrees to form a triangle

# Finish drawing
turtle.done()
